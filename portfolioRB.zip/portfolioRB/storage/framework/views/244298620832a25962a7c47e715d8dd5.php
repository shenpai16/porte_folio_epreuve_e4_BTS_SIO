<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/veille.css')); ?>">
    <title>Veille technologique</title>
</head>
<body>
    <?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <div class="texte">
            <h1>Apple vision pro</h1>
            <p>
                - Utilisation du phénomène de la stéréoscopie.
            </p>
            <p>
                - Regarder et pincer pour interagir.
            </p>
            <p>
                - Eye tracking.
            </p>
            <p>
                - Gesture Recognition.
            </p>
        </div>
        <img src="<?php echo e(asset('img/appleImg2.jpg')); ?>" class="custom-img2" alt="...">
    </div>
</body>
</html><?php /**PATH /var/www/html/portfolioRB/resources/views/veille.blade.php ENDPATH**/ ?>