<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/styleCard.css')); ?>">
    <title>Home</title>
</head>
<body>
    <?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div  class="titre">
        <h2>Mes stages</h2>
    </div>
<div class="card-container">
    <div class="d-flex-center">
        <div class="card" style="width: 18rem;">
        <img src="<?php echo e(asset('img/SSD_3jpg.jpg')); ?>" class="card-img-top custom-img" alt="...">
            <div class="card-body">
                <h5 class="card-title">Stage SIO 1</h5>
                <p class="card-text">Voir le stage de première année </p>
                <a href="<?php echo e(route('stage1')); ?>" class="btn btn-primary">En savoir plus</a>
            </div>
        </div>
    </div>

    <div class="d-flex-center">
        <div class="card" style="width: 18rem;">
        <img src="<?php echo e(asset('img/dev_2.jpg')); ?>" class="card-img-top custom-img" alt="...">
            <div class="card-body">
                <h5 class="card-title">Stage SIO 2</h5>
                <p class="card-text">Voir le stage de deuxieme année </p>
                <a href="<?php echo e(route('stage2')); ?>" class="btn btn-primary">En savoir plus</a>
            </div>
        </div>
    </div>
</div>

<div  class="titre">
    <h2>Veille technologique</h2>
</div>
<div class="d-flex-center">
    <div class="card" style="width: 18rem;">
        <img src="<?php echo e(asset('img/appleVision.jpg')); ?>" class="card-img-top custom-img2" alt="...">
            <div class="card-body">
                <h5 class="card-title">Apple Vision Pro</h5>
                <p class="card-text">Voir la veille technologique</p>
                <a href="<?php echo e(route('veille')); ?>" class="btn btn-primary">En savoir plus</a>
            </div>
    </div>
</div>

<div  class="titre2">        
    <h2>Mes projets</h2>
</div>

<div class="laDiv">
<div class="card-container">
    <div class="card2">
        <div class="card-image">
            <img src="<?php echo e(asset('img/PHP-logo.png')); ?>" alt="Image">
        </div>
        <div class="card-content">
            <h2>ImmoWeb</h2>
            <p>ImmoWeb est un projet web qui a pour but de réserver des locations tel que airBnB.</p>
        </div>
    </div>

    <div class="card2">
        <div class="card-image2">
            <img src="<?php echo e(asset('img/reactjs.jpg')); ?>" alt="Image">
        </div>
        <div class="card-content">
            <h2>ImmoApp</h2>
            <p>ImmoApp est un projet mobile qui a pour but de réaliser des états des lieux d'un appartement réservé.</p>
        </div>
    </div>
</div>
</div>

    

    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.9.1/gsap.min.js"></script>
    <script src="<?php echo e(asset('js/php.js')); ?>"></script> 
</body>
</html><?php /**PATH /var/www/html/portfolioRB/resources/views/index.blade.php ENDPATH**/ ?>