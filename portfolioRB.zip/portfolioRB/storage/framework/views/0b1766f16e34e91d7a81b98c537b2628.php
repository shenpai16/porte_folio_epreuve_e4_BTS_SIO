<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/stage1.css')); ?>">
    <title>Stage1</title>
</head>
<body>
    <?php echo $__env->make('nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <div class="texte">
            <h1>Présentation de l'entreprise</h1>
            <p>
                Lycée Margueritte se situant à Verdun (55100), ce lycée comporte deux sites de service informatique. Une se situant dans le lycée Margueritte avec à sa tête Philippe Pallo et la deuxième se situant au lycée Gallan avec Léo. 
            </p>
        </div>
        <img src="<?php echo e(asset('img/lycee_margerite.jpeg')); ?>" class="custom-img" alt="...">
    </div>

    

    <div class="container">
        <div class="texte">
            <h1>Mission confiées</h1>
            <p>
            Lors de mon stage, j'étais simplement un assistant de mon maître de stage. Je n'avais pas réellement d'objectif ou de projet défini ; mon travail se faisait plutôt au jour le jour.
            </p>
        </div>
    </div>


    <div class="container">
        <div class="texte">
            <h1>Difficultés rencontrées</h1>
            <p>
            Je n'ai pas rencontré de réel problème technique lors de mon stage. Le problème que j'ai rencontré est d'ordre social. Durant la deuxième semaine de mon stage, j'ai eu le plaisir d'apprendre qu'Abdulah allait me rejoindre pour effectuer son stage. On m'a souvent dit que l'hygiène de vie est importante dans la vie quotidienne et particulièrement en entreprise. C'est à ce moment-là que j'ai compris ce que cela signifiait. J'ai eu beaucoup de mal à travailler à côté de lui en raison du manque d'hygiène de mon collègue
            </p>
        </div>
    </div>

<div class="wrapper">
    <div class="container container2">
        <div class="texte">
            <h1>Semaine 1</h1>
            <p>- Visite des lycées Marguerite et Gallan et réglage des formalités administratives pour l'internat et la cantine.</p>
            <p>- Accompagnement de Philippe Pallo pour changer des SSD.</p>
            <p>- Création d'une image PC, installation de logiciels et mise à jour du système d'exploitation.</p>
            <p>- Copie de l'image sur d'autres SSD et installation dans les postes de travail.</p>
            <p>- Installation d'une salle de classe de SSD.</p> 
        </div>
    </div>

    <div class="container container2">
        <div class="texte">
            <h1>Semaine 2</h1>
            <p>- Production d'une nouvelle image PC.</p>
            <p>- Installation des logiciels demandés et mise à jour de l'image.</p>
            <p>- Copie de l'image sur d'autres SSD et installation dans les postes de travail.</p>
            <p>- Parallèlement, travail sur un projet personnel d'une agence de SMMA (Social Media Marketing Agency).</p>     
        </div>
    </div>
</div>

<div class="wrapper">
    <div class="container container2">
        <div class="texte">
            <h1>Semaine 3</h1>
            <p>- Préparation de PC portables pour les élèves en vue de leurs examens du bac.</p>
            <p>- Montage de nouveaux PC fixes pour une salle de classe.</p>
            <p>- Reproduction de l'image d'un PC pour les nouveaux postes, installation de logiciels et mises à jour.</p>
        </div>
    </div>

    <div class="container container2">
        <div class="texte">
            <h1>Semaine 4</h1>
            <p>- Démontage des anciens PC et installation des nouveaux postes dans la salle.</p>
            <p>- Gestion des câbles pour un câblage optimal.</p>   
        </div>
    </div>
</div>

<div class="wrapper">
    <div class="container container2">
        <div class="texte">
            <h1>Semaine 5</h1>
            <p>- Installation des logiciels demandés par les professeurs sur le SSD principal avant de faire des copies.</p>
            <p>- Objectif de remplacer une salle complète de 20 postes par de nouveaux postes.</p>
            <p>- Les PC étaient déjà montés, il ne manquait que les SSD.</p>
            <p>- Pas d'intervention dans la salle cette semaine-là en raison des cours.</p>
        </div>
    </div>

    <div class="container container2">
        <div class="texte">
            <h1>Semaine 6</h1>
            <p>- La salle était libre, ce qui a permis de commencer par mettre les SSD dans les 20 postes.</p>
            <p>- Enlèvement de tous les PC de la semaine précédente pour les remplacer par les nouveaux.</p>   
            <p>- Optimisation des nouveaux postes et intégration dans le domaine.</p>   
        </div>
    </div>
</div>
</body>
</html><?php /**PATH /var/www/html/portfolioRB/resources/views/stage1.blade.php ENDPATH**/ ?>