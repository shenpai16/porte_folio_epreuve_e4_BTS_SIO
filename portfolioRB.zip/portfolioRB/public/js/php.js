// Animation avec GSAP
const cardImage = document.querySelector('.card-image');

gsap.to(cardImage, {
    y: -20,
    duration: 1,
    repeat: -1,
    yoyo: true,
    ease: 'power1.inOut'
});

const cardImage2 = document.querySelector('.card-image2');
gsap.to(cardImage2, {
    y: -20,
    duration: 1,
    repeat: -1,
    yoyo: true,
    ease: 'power1.inOut'
});
