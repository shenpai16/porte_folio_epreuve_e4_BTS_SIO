document.addEventListener("DOMContentLoaded", function () {
    function isElementInViewport(el) {
        var rect = el.getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    }

    function startCounter() {
        var counterElement = document.getElementById("counter0");
        var targetValue = 370;
        var duration = 2000; 
        var interval = 20; 

        var stepValue = Math.ceil(targetValue / (duration / interval));
        var currentValue = 0;

        var counterInterval = setInterval(function () {
            if (currentValue < targetValue) {
                currentValue += stepValue;
                counterElement.innerText = currentValue;
            } else {
                counterElement.innerText = targetValue;
                clearInterval(counterInterval);
            }
        }, interval);
    }

    var card0 = document.getElementById("card0");

    function handleVisibility() {
        if (isElementInViewport(card0)) {
           
            startCounter();
           
            window.removeEventListener('scroll', handleVisibility);
        }
    }

  
    window.addEventListener('scroll', handleVisibility);

   
    handleVisibility();
});
