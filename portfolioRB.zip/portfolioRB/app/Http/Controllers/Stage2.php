<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Stage2 extends Controller
{
    public function afficherStage2(){
        return view('stage2', []);
    }
}
