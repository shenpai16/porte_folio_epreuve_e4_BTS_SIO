<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Stage1 extends Controller
{
    public function afficherStage1(){
        return view('stage1', []);
    }
}
