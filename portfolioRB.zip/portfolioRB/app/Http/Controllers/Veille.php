<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Veille extends Controller
{
    public function afficherVeille(){
        return view('veille', []);
    }
}
