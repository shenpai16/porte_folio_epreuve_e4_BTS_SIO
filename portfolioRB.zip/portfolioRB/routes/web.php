<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Index;
use App\Http\Controllers\Stage1;
use App\Http\Controllers\Stage2;
use App\Http\Controllers\Veille;




Route::get('/', [Index::class, 'afficherIndex'])->name('/');
Route::get('/stage1', [Stage1::class, 'afficherStage1'])->name('stage1');
Route::get('/stage2', [Stage2::class, 'afficherStage2'])->name('stage2');
Route::get('/veille', [Veille::class, 'afficherVeille'])->name('veille');

