<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="{{ asset('css/stage2.css') }}">
    <title>Stage 2</title>
</head>
<body>
    @include('nav')
    <div class="container">
        <div class="texte">
            <h1>Présentation de l'entreprise</h1>
            <p>
            J'ai effectué mon stage au lycée Pierre-Larousse, situé à Toucy (89130), sous la direction de Monsieur Benmimoune, proviseur et maître de stage. Cette institution comprend un collège, un lycée, une classe de SEGPA ainsi qu'un BTS Assurance. 
            </p>
        </div>
        <img src="{{ asset('img/toucy.jpg') }}" class="custom-img" alt="...">
    </div>

    <div class="wrapper">
    <div class="container container2">
        <div class="texte">
            <h1>Mission confiée</h1>
            <p>
            On m'a confié la mission de refaire le site web du lycée Pierre-Larousse <a href="https://cs-plarousse-toucy.eclat-bfc.fr/">(site toucy)</a>, dans le but d'adopter des normes de design modernes afin d'attirer davantage d'élèves et de donner une visibilité internationale à l'établissement.
            </p>
        </div>
    </div>

    <div class="container container2">
        <div class="texte">
            <h1>Deuxième mission confiée</h1>
            <p>
            Le deuxième projet qui m'a été attribué consiste à créer un site web permettant la gestion des fiches projet de l'établissement. Ce projet vise à automatiser l'entrée des fiches projet et à mettre en place un système de classification par année scolaire, en fonction du professeur assigné à chaque projet.
            </p>
        </div>
    </div>

</div>

    

    <div class="container">
        <div class="texte">
            <h1>Première réunion</h1>
            <p>
                - Réunion avec le proviseur pour établir le cahier des charges du site.
            </p>
            <p>
                - Désir du proviseur pour que le site reflète les couleurs caractéristiques du lycée, inspirées de la villa Majorelle à Marrakech.
            </p>
            <p>
                - Mise en place d'un nouveau jeu de couleurs pour le site.
            </p>
            <p>
                - Souhait du proviseur d'avoir un système de publication d'articles.
            </p>
            <p>
                - Processus de vérification préalable des articles par le proviseur avant publication.
            </p>
            <p>
                - Mécanisme d'envoi des articles par e-mail par l'auteur.
            </p>
            <p>
                - Disposition d'un lien pour le proviseur afin d'accepter ou de refuser les articles.
            </p>
            <p>
                - Objectif : garantir le contrôle du contenu et éviter la publication d'articles frauduleux.
            </p>


        </div>
        <img src="{{ asset('img/villa.jpg') }}" class="custom-img2" alt="...">
    </div>

    <div class="container">
        <div class="texte">
            <h1>Première contrainte</h1>
            <p>
                Confrontation à plusieurs dilemmes après l'établissement du cahier des charges :
            </p>
            <p>
                - Premièrement, choix de l'organisation du projet.
            </p>
            <p>
                - Sélection de l'outil de développement le plus approprié.
            </p>
            <p>
                - Décision sur le stockage du projet pour sa mise en ligne.
            </p>
        </div>
    </div>

    <div class="container">
        <div class="texte">
            <h1>Premier pas</h1>
            <p>
                - Contact avec le professeur Monsieur Piguet par e-mail pour solliciter son avis.
            </p>
            <p>
                - Demande de conseil sur l'utilisation du MVC ou de Laravel pour le projet.
            </p>
            <p>
                - Recommandation de Monsieur Piguet d'opter pour Laravel.
            </p>
            <p>
                - Raisons : nombreuses fonctionnalités de sécurité et efficacité dans la structuration du projet.
            </p>
        </div>
        <img src="{{ asset('img/laravel.jpg') }}" class="custom-img2" alt="...">
    </div>

    <div class="container">
        <div class="texte">
            <h1>Page de connexion et d'inscription</h1>
            <p>
                - Contact avec le professeur Monsieur Piguet par e-mail pour solliciter son avis.
            </p>
            <p>
                - Respect des normes de sécurité pour les mots de passe lors de l'inscription des utilisateurs : 12 caractères minimum, au moins une majuscule, une minuscule et un caractère spécial.
            </p>
            <p>
                - Implémentation d'un système de gestion des tentatives de connexion : après 10 tentatives infructueuses, le compte est suspendu pendant 30 minutes.
            </p>
            <p>
                - Enregistrement des tentatives de connexion ratées dans les logs, permettant de déclencher le blocage du compte en cas de tentatives suspectes, afin de prévenir les connexions frauduleuses ou malveillantes.
            </p>
        </div>
        <img src="{{ asset('img/inscription.png') }}" class="custom-img3" alt="...">
    </div>

    <div class="container">
        <div class="texte">
            <h1>Développement des articles dans le projet.</h1>
            <p>
                - Création d'un formulaire pour la publication d'articles avec des vérifications intégrées.
            </p>
            <p>
                - Vérifications des photos téléchargées : taille maximale du fichier, extension autorisée (.png, .jpg, .jpeg).
            </p>
            <p>
                - Conversion des images en format hexadécimal pour les stocker en tant que "Blob" dans la base de données.
            </p>
            <p>
                - Autorisation des liens dans les articles avec une vérification pour éviter les liens malveillants.
            </p>
            <p>
                - Stockage sécurisé des articles et des liens dans la base de données après vérification.
            </p>
        </div>
    </div>

    <div class="container">
        <div class="texte">
            <h1>Carte blanche.</h1>
            <p>
                - Premièrement, intégration d'un composant de petites cartes avec un logo et un nombre qui augmente au premier chargement, grâce à l'utilisation de CSS et de JavaScript.
            </p>
            <p>
                - Deuxièmement, création d'un carrousel en 3D pour ranger les articles et permettre aux visiteurs de lire et se renseigner sur les activités du lycée.
            </p>
           
        </div>
    </div>

    <div class="container">
        <div class="texte">
            <h1>Ajout d'une partie administrative.</h1>
            <p>
                - Création d'une section admin dans la barre de navigation, accessible uniquement par le proviseur.
            </p>
            <p>
                - Développement d'une interface utilisateur pour la modification et la suppression des données, facilitant ainsi la gestion des informations.
            </p>
           
        </div>
    </div>

    <div class="container">
        <div class="texte">
            <h1>Second site.</h1>
            <p>
                - Objectif : répertorier les fiches projets pour chaque professeur ou membre du personnel de l'éducation.
            </p>
            <p>
                - Chaque utilisateur possède un compte personnalisé permettant d'accéder aux fiches projets classées par année.
            </p>
        </div>
    </div>


    
</body>
</html>