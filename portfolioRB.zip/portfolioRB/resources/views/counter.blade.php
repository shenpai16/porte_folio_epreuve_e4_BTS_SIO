<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="{{ asset('css/counter.css') }}">

    <title>Document</title>
    <style>
        
    </style>
</head>
<body>
<div class="container">
    <div class="row justify-content-between">

        <div class="col-md-2">
            <div class="card custom-card"  id="card0">
                <div class="card-body text-center">
                    <div class="" id="counter0">370</div>
                    <p class="card-text">Personnels</p>
                </div>
            </div>
        </div>

   


       
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="{{ asset('js/counter.js') }}"></script> 
 
</body>
</html>